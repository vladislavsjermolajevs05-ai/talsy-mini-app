#Трогать, значения можно менять
admin = [285060597] #ID админа
support_name = '@botYanis' #Имя саппорта, будет выводиться при нажатии кнопки "поддержка"
token = '5675159912:AAHgN_mzWdbiNtQIq33yEJ2AjxJtIHyEGDE' #Токен бота
client_id = "" #client_id, получается при создании приложения Юмани
number_qiwi = '+79218681790' #Номер вашего QIWI кошелька
token_qiwi = '' #Токен киви
token_youmoney = ''  # Токен ЮМани
p2p_closed_token ='eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlpbl9tZXJjaGFudF9zaXRlX3VpZCI6Imx6MDN4OS0wMCIsInVzZXJfaWQiOiI3OTIxODY4MTc5MCIsInNlY3JldCI6ImQ1YzZlNmE3YjdhZTE3NzRiY2EzNDU4Nzg4NWQ1ODIwYjRhNDE2ZWMwMDJlZDA4ZmUzNTc5YjUzZTFlNGU3YzkifX0='  #Приватный ключ P2P QIWI
open_coinbase = '' #Публичный ключ CoinBase
close_coinbase = '' #Секретный токен CoinBase
secret_crystal = ''  #Секретный ключ кассы CrystalPay
login_crystal = ''  # Логин кассы CrystalPay

#Не трогать, значения должны быть по умолчанию
balance = 0
referals_ = 0
bill_id =  None
photo_id = None
text = None
auto_output = 0
amount = None
bet = 0
game = None
referal_level = 1
referer = None
referal_profit = 0
ban = 0
cash = 0
method = None
voucher = None
promo = None
winning = 0
demobalance = 0



